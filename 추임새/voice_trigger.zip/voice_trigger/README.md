# voice_trigger — 한국어 음성인식 → 음원 재생

마이크로 말하면 한국어로 인식하고, 인식된 말에 맞는 음원 파일을 재생합니다.
Apple Silicon(M1)용 `mlx-whisper`로 Mac 안에서만 처리합니다(인터넷 불필요, 첫 실행 때 모델 다운로드만).

## 1. 설치 (처음 한 번)

```bash
cd ~/voice_trigger          # 이 폴더를 둔 위치 (경로에 한글이 없으면 좋습니다)
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 2. 실행

```bash
source .venv/bin/activate
python voice_trigger.py
```

- 처음 실행하면 모델(약 1.5GB)을 받느라 몇 분 걸립니다.
- macOS가 터미널의 **마이크 권한**을 물으면 허용하세요.
- 종료: `Ctrl + C`

### 테스트용 명령

```bash
python voice_trigger.py --list-devices          # 마이크/스피커 번호·이름 확인
python voice_trigger.py --test "안녕하세요"        # 한 문장 매칭 테스트 (소리 재생)
python voice_trigger.py --type                  # 키보드로 문장 입력하며 테스트 (모델 불필요)
python voice_trigger.py --type --no-play        # 소리 없이 매칭 결과만 보기
```

## 3. 명령 추가하기 — `commands.json`

```json
{
  "name": "박수",
  "phrases": ["박수", "박수 쳐 줘", "잘했어"],
  "sounds": ["sounds/clap.wav", "sounds/clap2.mp3"],
  "volume": 0.8,
  "cooldown": 2,
  "match": "auto"
}
```

| 항목 | 설명 |
|---|---|
| `phrases` | 이 말들 중 하나가 문장에 들어 있으면 실행. 공백·문장부호는 무시됩니다 |
| `sounds` | 재생할 파일. 여러 개면 **무작위로 하나** 재생. wav, mp3, flac, ogg 가능 |
| `volume` | 볼륨 배율 (선택, 기본 1.0) |
| `cooldown` | 같은 명령을 다시 실행하기까지 기다릴 초 (선택) |
| `match` | `auto`(기본, 비슷하면 인정) · `contains`(글자 그대로 포함) · `exact`(문장 전체가 일치) |

- 음원 파일은 `sounds/` 폴더에 넣고 `"sounds/파일명.wav"`처럼 적으면 됩니다.
- **실행 중에 저장해도 바로 반영**됩니다(재시작 불필요).
- 아무 명령에도 안 맞을 때 재생할 소리: `"fallback": { "sounds": ["sounds/what.wav"] }`

## 4. 주요 설정 — `settings`

| 항목 | 기본값 | 설명 |
|---|---|---|
| `model` | whisper-large-v3-turbo | 느리면 `"mlx-community/whisper-small-mlx"` (빠르지만 정확도 ↓) |
| `input_device` / `output_device` | null(시스템 기본) | 번호 또는 이름 일부. 예: `"BlackHole"`, `"MacBook Air 스피커"` |
| `start_threshold_db` | -40 | 이보다 큰 소리를 말로 판단. 주변이 시끄러우면 -35, 인식을 못 하면 -45 |
| `silence_duration` | 0.7 | 이만큼 조용하면 말이 끝난 것으로 판단 (초) |
| `max_speech` | 8 | 한 번에 녹음하는 최대 길이 (초) |
| `match_threshold` | 75 | 0~100. 오작동이 많으면 올리고, 잘 안 걸리면 내리세요 |
| `play_mode` | interrupt | `interrupt`: 새 소리가 이전 소리를 끊음 / `skip_if_playing`: 재생 중엔 무시 |
| `ignore_while_playing` | true | 재생 중엔 마이크를 무시 (스피커 소리를 다시 인식하는 것 방지) |
| `use_phrases_as_prompt` | true | 등록한 단어를 모델에 힌트로 줘서 인식률을 높임 |
| `ignore_texts` | (목록) | Whisper가 무음에서 지어내는 문장(“시청해주셔서 감사합니다” 등) 무시 |

## 5. 다른 앱으로 소리 보내기 (디스코드, OBS, RVC 등)

`brew install blackhole-2ch` 설치 후 `"output_device": "BlackHole"`로 지정하고,
받는 앱의 마이크 입력을 BlackHole 2ch로 고르면 됩니다.

## 문제 해결

- **인식 결과가 안 뜸** → 화면에 `… 인식 중`이 안 나오면 `start_threshold_db`를 -45~-50으로 낮추기
- **말 중간에 잘림** → `silence_duration`을 1.0으로 늘리기
- **엉뚱한 명령 실행** → `match_threshold`를 85로 올리거나 해당 명령에 `"match": "contains"`
- **mp3 재생 오류** → `pip install -U soundfile` 또는 wav로 변환
